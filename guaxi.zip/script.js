// ============================================================
// Guaxinim Tempo Real — Main Script
// ============================================================

// ─── STATE ──────────────────────────────────────────────────
let currentCity = "São Paulo";
let isAutoTime = true;
let manualTimeVal = 12;

let isAutoSeason = true;
let manualSeasonVal = "summer";

let isAutoWeather = true;
let manualWeatherVal = "clear";

let tree1Pct = 15,
  tree1YOff = 0;
let tree2Pct = 80,
  tree2YOff = 0;
let bonfirePct = 65,
  bonfireYOff = 0;

let centerTreeYOffset =
  parseInt(localStorage.getItem("centerTreeYOffset")) || 160;
let sheetBottomNudgeValNum =
  parseInt(localStorage.getItem("sheetBottomNudge")) || 0;

// raccoon runtime state
let raccoonState = "idle";
let raccoonScale = 1;
let raccoonX = window.innerWidth / 2;
let randomHoleTime = Date.now() + Math.random() * 30000;
let externalWeather = null;
let externalWeatherFetchedAt = 0;
let lightningFlash = 0;
let raccoon = { bounceOffset: 0, flip: false, frame: 0 };
let centerTreeUsingSheetTop = false;

// ─── UI REFERENCES ───────────────────────────────────────────
const uiToggle = document.getElementById("ui-toggle");
const uiPanel = document.getElementById("ui-panel");
const cityInput = document.getElementById("city-input");

const overrideTime = document.getElementById("override-time");
const timeSlider = document.getElementById("time-slider");
const timeDisplay = document.getElementById("time-display");

const overrideSeason = document.getElementById("override-season");
const seasonSelect = document.getElementById("season-select");

const overrideWeather = document.getElementById("override-weather");
const weatherSelect = document.getElementById("weather-select");

const tree1Slider = document.getElementById("tree1-x");
const tree1YSlider = document.getElementById("tree1-y");
const tree1XValEl = document.getElementById("tree1-x-val");
const tree1YValEl = document.getElementById("tree1-y-val");

const tree2Slider = document.getElementById("tree2-x");
const tree2YSlider = document.getElementById("tree2-y");
const tree2XValEl = document.getElementById("tree2-x-val");
const tree2YValEl = document.getElementById("tree2-y-val");

const bonfireSlider = document.getElementById("bonfire-x");
const bonfireYSlider = document.getElementById("bonfire-y");
const bonfireXValEl = document.getElementById("bonfire-x-val");
const bonfireYValEl = document.getElementById("bonfire-y-val");

const centerTreeYSlider = document.getElementById("center-tree-y");
const centerTreeYValDisp = document.getElementById("center-tree-y-val");
const saveCenterTreeBtn = document.getElementById("save-center-tree");

const sheetBottomNudgeSlider = document.getElementById("sheet-bottom-nudge");
const sheetBottomNudgeValDisp = document.getElementById(
  "sheet-bottom-nudge-val",
);
const saveSheetBottomBtn = document.getElementById("save-sheet-bottom");

const raccoonImageInput = document.getElementById("raccoon-image-input");
const bonfireImageInput = document.getElementById("bonfire-image-input");
const treeInputs = document.querySelectorAll(".tree-input");

// ─── UI EVENT LISTENERS ──────────────────────────────────────
if (uiToggle)
  uiToggle.addEventListener("click", () => uiPanel.classList.toggle("open"));

if (overrideTime)
  overrideTime.addEventListener("change", (e) => {
    isAutoTime = !e.target.checked;
    timeSlider.classList.toggle("hidden", isAutoTime);
  });
if (timeSlider)
  timeSlider.addEventListener("input", (e) => {
    manualTimeVal = parseFloat(e.target.value);
  });

if (overrideSeason)
  overrideSeason.addEventListener("change", (e) => {
    isAutoSeason = !e.target.checked;
    seasonSelect.classList.toggle("hidden", isAutoSeason);
  });
if (seasonSelect)
  seasonSelect.addEventListener("change", (e) => {
    manualSeasonVal = e.target.value;
  });

if (overrideWeather)
  overrideWeather.addEventListener("change", (e) => {
    isAutoWeather = !e.target.checked;
    weatherSelect.classList.toggle("hidden", isAutoWeather);
    if (isAutoWeather) fetchWeatherForCity(currentCity);
  });
if (weatherSelect)
  weatherSelect.addEventListener("change", (e) => {
    manualWeatherVal = e.target.value;
  });

// Position sliders – X
if (tree1Slider)
  tree1Slider.addEventListener("input", (e) => {
    tree1Pct = parseFloat(e.target.value);
    if (tree1XValEl) tree1XValEl.innerText = tree1Pct.toFixed(0) + "%";
  });
if (tree2Slider)
  tree2Slider.addEventListener("input", (e) => {
    tree2Pct = parseFloat(e.target.value);
    if (tree2XValEl) tree2XValEl.innerText = tree2Pct.toFixed(0) + "%";
  });
if (bonfireSlider)
  bonfireSlider.addEventListener("input", (e) => {
    bonfirePct = parseFloat(e.target.value);
    if (bonfireXValEl) bonfireXValEl.innerText = bonfirePct.toFixed(0) + "%";
  });

// Position sliders – Y
if (tree1YSlider)
  tree1YSlider.addEventListener("input", (e) => {
    tree1YOff = parseInt(e.target.value);
    if (tree1YValEl) tree1YValEl.innerText = tree1YOff + "px";
  });
if (tree2YSlider)
  tree2YSlider.addEventListener("input", (e) => {
    tree2YOff = parseInt(e.target.value);
    if (tree2YValEl) tree2YValEl.innerText = tree2YOff + "px";
  });
if (bonfireYSlider)
  bonfireYSlider.addEventListener("input", (e) => {
    bonfireYOff = parseInt(e.target.value);
    if (bonfireYValEl) bonfireYValEl.innerText = bonfireYOff + "px";
  });

if (centerTreeYSlider) {
  centerTreeYSlider.value = centerTreeYOffset;
  if (centerTreeYValDisp)
    centerTreeYValDisp.innerText = centerTreeYOffset + "px";
  centerTreeYSlider.addEventListener("input", (e) => {
    centerTreeYOffset = parseInt(e.target.value);
    if (centerTreeYValDisp)
      centerTreeYValDisp.innerText = centerTreeYOffset + "px";
  });
}
if (saveCenterTreeBtn)
  saveCenterTreeBtn.addEventListener("click", () => {
    localStorage.setItem("centerTreeYOffset", String(centerTreeYOffset));
    saveCenterTreeBtn.innerText = "Saved!";
    setTimeout(() => {
      saveCenterTreeBtn.innerText = "Save";
    }, 2000);
  });

if (sheetBottomNudgeSlider) {
  sheetBottomNudgeSlider.value = sheetBottomNudgeValNum;
  if (sheetBottomNudgeValDisp)
    sheetBottomNudgeValDisp.innerText = sheetBottomNudgeValNum + "px";
  sheetBottomNudgeSlider.addEventListener("input", (e) => {
    sheetBottomNudgeValNum = parseInt(e.target.value);
    if (sheetBottomNudgeValDisp)
      sheetBottomNudgeValDisp.innerText = sheetBottomNudgeValNum + "px";
  });
}
if (saveSheetBottomBtn)
  saveSheetBottomBtn.addEventListener("click", () => {
    localStorage.setItem("sheetBottomNudge", String(sheetBottomNudgeValNum));
    saveSheetBottomBtn.innerText = "Saved!";
    setTimeout(() => {
      saveSheetBottomBtn.innerText = "Save";
    }, 2000);
  });

// File inputs
if (raccoonImageInput)
  raccoonImageInput.addEventListener("change", (e) => {
    if (!e.target.files[0]) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      raccoonImg.src = evt.target.result;
    };
    reader.readAsDataURL(e.target.files[0]);
  });

if (bonfireImageInput)
  bonfireImageInput.addEventListener("change", (e) => {
    if (!e.target.files[0]) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      bonfireImgLoaded = false;
      bonfireImg.src = evt.target.result;
      bonfireImg.onload = () => {
        bonfireImgLoaded = true;
      };
    };
    reader.readAsDataURL(e.target.files[0]);
  });

treeInputs.forEach((input) => {
  input.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const season = input.dataset.season;
    const type = input.dataset.type; // 'small' or 'center'
    const btn = document.getElementById(`${season}-${type}-btn`);
    const reader = new FileReader();
    reader.onload = (evt) => {
      const img = new Image();
      img.src = evt.target.result;
      img.onload = () => {
        if (!treeImgs[season]) treeImgs[season] = {};
        treeImgs[season][type] = img;
        getBottomYFromRegion(
          img,
          0,
          0,
          img.naturalWidth,
          img.naturalHeight,
          _bottomCacheImg,
          img.src,
        );
        if (btn) {
          btn.classList.add("loaded");
          btn.innerText = "OK";
        }
      };
    };
    reader.readAsDataURL(file);
  });
});

// City input (debounced)
let cityFetchTimeout = null;
if (cityInput)
  cityInput.addEventListener("input", (e) => {
    currentCity = e.target.value;
    if (cityFetchTimeout) clearTimeout(cityFetchTimeout);
    cityFetchTimeout = setTimeout(() => fetchWeatherForCity(currentCity), 800);
  });

// ─── CANVAS ──────────────────────────────────────────────────
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d", { alpha: false });

// ─── THEMES & COLORS ─────────────────────────────────────────
const THEMES = {
  manha: {
    sky1: "#74b9ff",
    sky2: "#81ecec",
    sky3: "#ffeaa7",
    mountain: "#827397",
    mountainLight: "#a29bfe",
  },
  dia: {
    sky1: "#0984e3",
    sky2: "#74b9ff",
    sky3: "#81ecec",
    mountain: "#4a5b63",
    mountainLight: "#636e72",
  },
  tarde: {
    sky1: "#6c5ce7",
    sky2: "#e84393",
    sky3: "#fdcb6e",
    mountain: "#1b1b2f",
    mountainLight: "#2d3436",
  },
  noite: {
    sky1: "#000000",
    sky2: "#1e272e",
    sky3: "#0f1423",
    mountain: "#0a0a0f",
    mountainLight: "#1e272e",
  },
};

const SEASON_COLORS = {
  spring: {
    grass1: "#55efc4",
    grass2: "#00b894",
    leafM: "#fd79a8",
    leafN: "#e84393",
    leafE: "#d63031",
  },
  summer: {
    grass1: "#78e08f",
    grass2: "#38ada9",
    leafM: "#2ecc71",
    leafN: "#27ae60",
    leafE: "#1e8449",
  },
  autumn: {
    grass1: "#e58e26",
    grass2: "#b71540",
    leafM: "#f39c12",
    leafN: "#d35400",
    leafE: "#e67e22",
  },
  winter: {
    grass1: "#dfe6e9",
    grass2: "#b2bec3",
    leafM: "#ecf0f1",
    leafN: "#bdc3c7",
    leafE: "#95a5a6",
  },
};

const BASE_COLORS = {
  T: null,
  K: "#1e272e",
  B: "#834c32",
  D: "#5c3a21",
  S: "#f1c40f",
  O: "#e67e22",
  C: "#f5f6fa",
  Y: "#ffffff",
  V: "#dcdde1",
  I: "#7f8fa6",
  G: "#a5b1c2",
  A: "#485460",
  R: "#ff9ff3",
  P: "#f368e0",
  F: "#e74c3c",
};

function getColor(char, season) {
  if (BASE_COLORS[char] !== undefined) return BASE_COLORS[char];
  const sc = SEASON_COLORS[season];
  if (char === "M") return sc.leafM;
  if (char === "N") return sc.leafN;
  if (char === "E") return sc.leafE;
  return "#000";
}

// ─── SPRITE DEFINITIONS ──────────────────────────────────────
const TREE = [
  "TTTTTTTTTTKKKKKKTTTTTTTTTT",
  "TTTTTTTKKKMMMMMMKKKTTTTTTT",
  "TTTTTKKMMMMMMMMMMMMKKTTTTT",
  "TTTTKMMMMMMNNNNMMMMMMKTTTT",
  "TTTKMMMMMNNNNNNNNMMMMMKTTT",
  "TTKMMMMMNNNNNNNNNNMMMMMKTT",
  "TKMMMMMNNNNNNNNNNNNMMMMKTT",
  "TKMMMMNNNNNNNNNNNNNNMMMMKT",
  "KMMMMNNNNNNNNNNNNNNNNMMMMK",
  "KMMMNNNNNNNEEEENNNNNNNMMMK",
  "KMMMNNNNNNEEEEEEENNNNNMMMK",
  "KMMNNNNNNNEEEEEEEENNNNNMMK",
  "TKNNNNNNNNEEEEEEEENNNNNNKT",
  "TKNNNNNNNNEEEEEEEENNNNNNKT",
  "TTKNNNNNNNEEEEEEEENNNNNKTT",
  "TTTKKNNNNNEEEEEEENNNNKKTTT",
  "TTTTTKKNNNEEEEEENNNKKTTTTT",
  "TTTTTTTKKNEEEEEENKKTTTTTTT",
  "TTTTTTTTTKKEEEEKKTTTTTTTTT",
  "TTTTTTTTTTTKBBKTTTTTTTTTTT",
  "TTTTTTTTTTTKBDBKTTTTTTTTTT",
  "TTTTTTTTTTTKBDBKTTTTTTTTTT",
  "TTTTTTTTTTTKKKKKTTTTTTTTTT",
  "TTTTTTTTTTTKKKKKTTTTTTTTTT",
  "TTTTTTTTTTKKKKKKKTTTTTTTTT",
  "TTTTTTTTTKKKKKKKKKTTTTTTTT",
  "TTTTTTTTTKKKKKKKKKTTTTTTTT",
];

const BONFIRE_1 = [
  "TTTTTFTTTTT",
  "TTTTFOFTTTT",
  "TTTOOOFTTTT",
  "TTFOOSOFTTT",
  "TFOOSSOOFTT",
  "TFOOSSSOFTT",
  "FOOSSSSSOFT",
  "KDKKBBKKDKT",
  "TKDBKKBDKTT",
  "TTKKKKKTTTT",
];
const BONFIRE_2 = [
  "TTTTTTFTTTT",
  "TTTTTFOFTTT",
  "TTTTOOFTTTT",
  "TTTOOSOFTTT",
  "TTFOOSOOFTT",
  "TFOOSSSOFTT",
  "FOOSSSSSOFT",
  "KDKKBBKKDKT",
  "TKDBKKBDKTT",
  "TTKKKKKTTTT",
];

const BUSH = [
  "TTTTTTMMMMMNTTTTTT",
  "TTTTMMMMMMNNNNTTTT",
  "TTTMMMMMMNNNNNETTT",
  "TTMMMMMMMNNNNNEETT",
  "TMMMMMMNNNNNEEEEET",
  "MMMMMNNNNNEEEEEEEE",
  "MMMMNNNNNNEEEEEEEE",
];

const FLOWER = ["TRT", "RPR", "TRT", "TNT", "MNN"];

const ROCK = ["TTGGTT", "TGGGGT", "GDDGGA", "DAAADA"];

const SUN = [
  "TTTTTTTSTTTTTTT",
  "TTTTTTTSTTTTTTT",
  "TTSTTTTSTTTTSTT",
  "TTTSTOOSSOOSTTT",
  "TTTTOOSSSSOOTTT",
  "TTTOSSSYYSSSOTT",
  "TTOSSYYYYYYSSOT",
  "SSOSYYYYYYYYOSS",
  "TTOSSYYYYYYSSOT",
  "TTTOSSSYYSSSOTT",
  "TTTTOOSSSSOOTTT",
  "TTTSTOOSSOOSTTT",
  "TTSTTTTSTTTTSTT",
  "TTTTTTTSTTTTTTT",
  "TTTTTTTSTTTTTTT",
];

const MOON = [
  "TTTTTCCCCCCCTTTT",
  "TTTCCVVVVCCCCCCT",
  "TTCVVVVVVVVCCCCT",
  "TCCVVVVVCCCVVVCT",
  "TCCCVVVCCCCVVVCT",
  "TCCCCCCCCCCVVVCT",
  "CCCVCCCCCCCCCCCC",
  "CCVVVCCCCCCCCCCC",
  "CCVVVCCCCCVVVCCC",
  "CCCVCCCCCVVVVVCC",
  "TCCCCCCCCCVVVVCT",
  "TCCCCCCCCCCVVVCT",
  "TTCCCCCVVVCCCCTT",
  "TTTCCCCCVCCCCCTT",
  "TTTTTCCCCCCCTTTT",
  "TTTTTTTTTTTTTTTT",
];

const CLOUD = [
  "TTTTTTTTYYYYTTTTTTTT",
  "TTTTTTYYYYYYYYTTTTTT",
  "TTTTYYYYYYYYYYYYTTTT",
  "TTYYYYYYYYYYYYYYYYTT",
  "YYYYYYYYYYYYYYYYYYYY",
  "YYYYYYYYYYYYYYYYYYYY",
  "TYYYYYYYYYYYYYYYYYYT",
];

// ─── IMAGES ──────────────────────────────────────────────────
const raccoonImg = new Image();
raccoonImg.src = "ässets/guaxinim_inteiro_transp.png";

const bonfireImg = new Image();
let bonfireImgLoaded = false;
bonfireImg.onload = () => {
  bonfireImgLoaded = true;
};
bonfireImg.onerror = () => {
  bonfireImgLoaded = false;
};
bonfireImg.src = "ässets/bonfire.png";

const treesSheet = new Image();
let treesSheetLoaded = false;
treesSheet.onload = () => {
  treesSheetLoaded = true;
  try {
    const shW = treesSheet.naturalWidth,
      shH = treesSheet.naturalHeight;
    const tW = shW / 4,
      tH = shH / 2;
    for (let col = 0; col < 4; col++) {
      for (let row = 0; row < 2; row++) {
        try {
          getBottomYFromRegion(
            treesSheet,
            col * tW,
            row * tH,
            tW,
            tH,
            _bottomCacheSheet,
            `${col}_${row}`,
          );
        } catch (e) {}
      }
    }
  } catch (e) {}
};
treesSheet.onerror = () => {
  treesSheetLoaded = false;
};
treesSheet.src = "ässets/trees_sheet.png";

const treeImgs = {
  spring: { center: new Image(), small: new Image() },
  summer: { center: new Image(), small: new Image() },
  autumn: { center: new Image(), small: new Image() },
  winter: { center: new Image(), small: new Image() },
};

function loadTreeImages() {
  // Center trees — use the "_out" variant (tree without raccoon baked in)
  treeImgs.spring.center.src = "ässets/spring_out.png";
  treeImgs.summer.center.src = "ässets/summer_out.png";
  treeImgs.autumn.center.src = "ässets/autum_out.png";
  treeImgs.winter.center.src = "ässets/winter_out.png";

  // Small side trees
  treeImgs.spring.small.src = "ässets/spring_small.png";
  treeImgs.summer.small.src = "ässets/summer_small.png";
  treeImgs.autumn.small.src = "ässets/autum_small.png";
  treeImgs.winter.small.src = "ässets/winter_small.png";

  Object.entries(treeImgs).forEach(([season, seasonImgs]) => {
    Object.entries(seasonImgs).forEach(([type, img]) => {
      img.onload = () => {
        try {
          if (img.complete && img.naturalWidth) {
            getBottomYFromRegion(
              img,
              0,
              0,
              img.naturalWidth,
              img.naturalHeight,
              _bottomCacheImg,
              img.src,
            );
          }
        } catch (e) {}
        const btn = document.getElementById(`${season}-${type}-btn`);
        if (btn) {
          btn.classList.add("loaded");
          btn.innerText = "OK";
        }
      };
      img.onerror = () => {
        const btn = document.getElementById(`${season}-${type}-btn`);
        if (btn) {
          btn.innerText = "—";
          btn.style.opacity = "0.5";
        }
      };
    });
  });
}

// hole placement as fraction of image (for raccoon hiding)
const holeFrac = { x: 0.5, y: 0.76, r: 0.11 };

// ─── PARTICLES & ENVIRONMENT ─────────────────────────────────
let grassBlades = [];
function initGrass() {
  grassBlades = Array.from({ length: 300 }, () => ({
    x: Math.random() * window.innerWidth * 2,
    height: Math.random() * 15 + 5,
    width: Math.random() * 4 + 2,
    isFlower: Math.random() > 0.95,
  }));
}

const _bottomCacheSheet = {};
const _bottomCacheImg = {};
const _offscreen = document.createElement("canvas");
const _offCtx = _offscreen.getContext("2d");

function getBottomYFromRegion(img, sx, sy, sw, sh, cache, cacheKey) {
  if (cache[cacheKey] !== undefined) return cache[cacheKey];
  const sxI = Math.max(0, Math.floor(sx));
  const syI = Math.max(0, Math.floor(sy));
  const w = Math.max(1, Math.floor(sw));
  const h = Math.max(1, Math.floor(sh));
  _offscreen.width = w;
  _offscreen.height = h;
  try {
    _offCtx.clearRect(0, 0, w, h);
    _offCtx.drawImage(img, sxI, syI, w, h, 0, 0, w, h);
    const data = _offCtx.getImageData(0, 0, w, h).data;
    function px(ix, iy) {
      const idx = (iy * w + ix) * 4;
      return [data[idx], data[idx + 1], data[idx + 2], data[idx + 3]];
    }
    const [bgR, bgG, bgB] = px(0, 0);
    const threshold = 30;
    for (let y = h - 1; y >= 0; y--) {
      const rowBase = y * w * 4;
      for (let x = 0; x < w; x++) {
        const b = rowBase + x * 4;
        const r = data[b],
          g = data[b + 1],
          bl = data[b + 2],
          a = data[b + 3];
        const dist = Math.sqrt(
          (r - bgR) ** 2 + (g - bgG) ** 2 + (bl - bgB) ** 2,
        );
        if (a > 10 || dist > threshold) {
          cache[cacheKey] = y;
          return y;
        }
      }
    }
  } catch (e) {
    console.warn("getBottomYFromRegion failed:", e && e.message);
  }
  cache[cacheKey] = h - 1;
  return h - 1;
}

const fireflies = Array.from({ length: 25 }, () => ({
  x: Math.random() * window.innerWidth,
  y: Math.random() * window.innerHeight * 0.3 + window.innerHeight * 0.6,
  phase: Math.random() * Math.PI * 2,
  speedX: (Math.random() - 0.5) * 0.5,
  speedY: (Math.random() - 0.5) * 0.5,
}));

const stars = Array.from({ length: 150 }, () => ({
  x: Math.random(),
  y: Math.random(),
  speed: Math.random() * 0.05,
  twinkle: Math.random() * Math.PI * 2,
}));

const clouds = [
  { x: 10, y: 15, speed: 0.5, scale: 6 },
  { x: 50, y: 10, speed: 0.3, scale: 4 },
  { x: 80, y: 25, speed: 0.8, scale: 5 },
  { x: 20, y: 35, speed: 0.4, scale: 7 },
];

const snowflakes = Array.from({ length: 200 }, () => ({
  x: Math.random() * window.innerWidth,
  y: Math.random() * window.innerHeight,
  speedY: Math.random() * 1 + 0.5,
  speedX: (Math.random() - 0.5) * 0.5,
  size: Math.random() * 3 + 1,
}));

const shootingStars = [];

// ─── DRAW UTILITIES ──────────────────────────────────────────
function drawSprite(sprite, startX, startY, scale, season, flip = false) {
  for (let y = 0; y < sprite.length; y++) {
    const row = sprite[y];
    for (let x = 0; x < row.length; x++) {
      const char = row[x];
      if (char === "T") continue;
      const drawX = flip ? row.length - 1 - x : x;
      ctx.fillStyle = getColor(char, season);
      ctx.fillRect(startX + drawX * scale, startY + y * scale, scale, scale);
    }
  }
}

function drawBlockyMountain(
  centerX,
  groundY,
  peakHeight,
  baseWidth,
  colorShadow,
  colorLight,
  hasSnow,
) {
  const blockSize = 16;
  const steps = Math.max(1, Math.floor(peakHeight / blockSize));
  const stepWidth = baseWidth / 2 / steps;
  for (let i = 0; i < steps; i++) {
    const currentY = groundY - i * blockSize;
    const currentHalfWidth = baseWidth / 2 - i * stepWidth;
    ctx.fillStyle = hasSnow && i > steps * 0.65 ? "#dfe6e9" : colorShadow;
    ctx.fillRect(
      centerX - currentHalfWidth,
      currentY - blockSize,
      currentHalfWidth,
      blockSize,
    );
    ctx.fillStyle = hasSnow && i > steps * 0.65 ? "#ffffff" : colorLight;
    ctx.fillRect(centerX, currentY - blockSize, currentHalfWidth, blockSize);
  }
}

function drawRain(groundY, intensity) {
  const dropCount = Math.floor(100 + intensity * 200);
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.lineWidth = 1;
  for (let i = 0; i < dropCount; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    const len = 10 + Math.random() * 15;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - 4, y + len);
    ctx.stroke();
  }
  ctx.fillStyle = "rgba(255,255,255,0.05)";
  for (let i = 0; i < 15; i++) {
    const px = Math.random() * canvas.width;
    const py = groundY + Math.random() * (canvas.height - groundY);
    ctx.beginPath();
    ctx.arc(px, py, 6 + Math.random() * 10, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawSnow() {
  ctx.fillStyle = "rgba(255,255,255,0.8)";
  snowflakes.forEach((f) => {
    ctx.beginPath();
    ctx.arc(f.x, f.y, f.size, 0, Math.PI * 2);
    ctx.fill();
    f.y += f.speedY;
    f.x += f.speedX;
    if (f.y > canvas.height) {
      f.y = -10;
      f.x = Math.random() * canvas.width;
    }
  });
}

// ─── TIME / SEASON / WEATHER ─────────────────────────────────
function getActiveTime() {
  if (!isAutoTime) return manualTimeVal;
  const now = new Date();
  return now.getHours() + now.getMinutes() / 60;
}

function getTimeTheme(h) {
  if (h >= 6 && h < 9) return "manha";
  if (h >= 9 && h < 17) return "dia";
  if (h >= 17 && h < 18) return "tarde";
  return "noite";
}

function getActiveSeason(date) {
  if (!isAutoSeason) return manualSeasonVal;
  const month = date.getMonth() + 1;
  if ([12, 1, 2, 3].includes(month)) return "summer";
  if ([9, 10, 11].includes(month)) return "spring";
  if ([6, 7, 8].includes(month)) return "winter";
  return "autumn";
}

function getActiveWeather(h, season, date) {
  if (!isAutoWeather) return manualWeatherVal;
  const nowTs = Date.now();
  if (externalWeather && nowTs - externalWeatherFetchedAt < 5 * 60 * 1000)
    return externalWeather;
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const seed = Math.sin(day * 23 + month * 7 + Math.floor(h) * 17) * 10000;
  const v = seed - Math.floor(seed);
  let rainChance = 0.45;
  if (season === "summer") rainChance = 0.75;
  if (season === "spring") rainChance = 0.55;
  if (season === "winter") rainChance = 0.6;
  if (h >= 12 && h < 18) {
    if (v < rainChance) {
      if (season === "winter") return "snow";
      return v < rainChance * 0.6 ? "rain" : "storm";
    }
    return v < 0.75 ? "cloudy" : "clear";
  }
  if (h >= 6 && h < 12) {
    if (v < 0.35) {
      if (season === "winter" && v < 0.15) return "snow";
      return "cloudy";
    }
    return "clear";
  }
  if (v < 0.4) {
    if (season === "winter" && v < 0.2) return "snow";
    return "cloudy";
  }
  return "clear";
}

function weatherCodeToCategory(code) {
  if (code === 0) return "clear";
  if ([1, 2, 3, 45, 48].includes(code)) return "cloudy";
  if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return "rain";
  if (code >= 95 && code <= 99) return "storm";
  if (code >= 71 && code <= 77) return "snow";
  return "cloudy";
}

let geocodeAbortController = null;
let weatherAbortController = null;

async function fetchWeatherForCity(city) {
  if (!city || !city.trim()) return;
  try {
    if (geocodeAbortController) geocodeAbortController.abort();
    geocodeAbortController = new AbortController();
    const geoRes = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(city)}`,
      { signal: geocodeAbortController.signal },
    );
    const geoJson = await geoRes.json();
    if (!geoJson || !geoJson[0]) return;
    const lat = parseFloat(geoJson[0].lat);
    const lon = parseFloat(geoJson[0].lon);
    if (weatherAbortController) weatherAbortController.abort();
    weatherAbortController = new AbortController();
    const wres = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`,
      { signal: weatherAbortController.signal },
    );
    const wjson = await wres.json();
    if (
      wjson &&
      wjson.current_weather &&
      wjson.current_weather.weathercode !== undefined
    ) {
      externalWeather = weatherCodeToCategory(
        wjson.current_weather.weathercode,
      );
      externalWeatherFetchedAt = Date.now();
    }
  } catch (e) {
    /* ignore abort / network errors */
  }
}

function updateTimeDisplay(h) {
  if (!timeDisplay) return;
  const hours = Math.floor(h);
  const minutes = Math.floor((h - hours) * 60);
  timeDisplay.innerText = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function drawWeatherText(weather, themeName, season) {
  const live =
    externalWeather && Date.now() - externalWeatherFetchedAt < 5 * 60 * 1000
      ? " · live"
      : "";
  const label = `${currentCity} · ${season.toUpperCase()} · ${weather.toUpperCase()}${live} · ${themeName.toUpperCase()}`;
  ctx.font = '16px "Outfit", sans-serif';
  ctx.textAlign = "left";
  ctx.fillStyle = "rgba(255,255,255,0.9)";
  ctx.shadowColor = "rgba(0,0,0,0.5)";
  ctx.shadowBlur = 4;
  ctx.fillText(label, 20, 35);
  ctx.shadowBlur = 0;
}

// ─── RESIZE ──────────────────────────────────────────────────
function resize() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  raccoonX = canvas.width / 2;
  initGrass();
}

// ─── MAIN LOOP ───────────────────────────────────────────────
function loop() {
  const now = new Date();
  const h = getActiveTime();
  updateTimeDisplay(h);

  const themeName = getTimeTheme(h);
  const theme = THEMES[themeName];
  const season = getActiveSeason(now);
  const weather = getActiveWeather(h, season, now);

  const isNight = h >= 18 || h < 6;
  const groundY = canvas.height * 0.75;

  // approximate hole target (refined after drawing center tree)
  let centerHoleTarget = canvas.width / 2;
  const centerTreeX = canvas.width / 2 - 40;

  // ── Raccoon AI ──────────────────────────────────────────────
  const isUncomfortable =
    weather === "rain" || weather === "storm" || weather === "snow";
  if (Date.now() > randomHoleTime + 15000)
    randomHoleTime = Date.now() + Math.random() * 40000 + 10000;
  const isRandomlyHiding =
    Date.now() > randomHoleTime && Date.now() < randomHoleTime + 15000;
  const shouldHide = isUncomfortable || isRandomlyHiding;

  const targetX = shouldHide ? centerHoleTarget : canvas.width / 2;
  const speed = canvas.width * 0.003;
  if (Math.abs(raccoonX - targetX) > speed) {
    raccoonState = "walking";
    if (raccoonX < targetX) {
      raccoonX += speed;
      raccoon.flip = false;
    } else {
      raccoonX -= speed;
      raccoon.flip = true;
    }
    raccoonScale = 1;
  } else {
    if (shouldHide) {
      raccoonState = "hiding";
      raccoonScale = Math.max(0, raccoonScale - 0.05);
    } else {
      raccoonState = "idle";
      raccoonScale = Math.min(1, raccoonScale + 0.05);
    }
  }

  // ── 1. SKY ──────────────────────────────────────────────────
  const skyGrad = ctx.createLinearGradient(0, 0, 0, canvas.height * 0.8);
  skyGrad.addColorStop(0, theme.sky1);
  skyGrad.addColorStop(0.4, theme.sky2);
  skyGrad.addColorStop(1, theme.sky3);
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // ── 2. Weather darkness overlay ─────────────────────────────
  if (weather === "cloudy" || weather === "snow") {
    ctx.fillStyle = "rgba(0,0,0,0.12)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  } else if (weather === "rain") {
    ctx.fillStyle = "rgba(0,0,20,0.15)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  } else if (weather === "storm") {
    ctx.fillStyle = "rgba(0,0,30,0.25)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (Math.random() < 0.02) lightningFlash = 8;
  }

  // ── 3. Stars & shooting stars (night) ───────────────────────
  if (isNight) {
    stars.forEach((s) => {
      s.twinkle += s.speed;
      ctx.fillStyle = `rgba(255,255,255,${(Math.sin(s.twinkle) + 1) / 2})`;
      ctx.fillRect(s.x * canvas.width, s.y * canvas.height * 0.7, 4, 4);
    });
    if (Math.random() < 0.005 && weather === "clear") {
      shootingStars.push({
        x: Math.random() * canvas.width,
        y: 0,
        len: Math.random() * 50 + 20,
        speed: Math.random() * 5 + 10,
      });
    }
    shootingStars.forEach((ss, i) => {
      ctx.strokeStyle = "rgba(255,255,255,0.8)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(ss.x, ss.y);
      ctx.lineTo(ss.x - ss.len, ss.y - ss.len);
      ctx.stroke();
      ss.x += ss.speed;
      ss.y += ss.speed;
      if (ss.y > canvas.height) shootingStars.splice(i, 1);
    });
  }

  // ── 4. Sun or Moon ──────────────────────────────────────────
  if (!isNight) {
    const tp = (h - 6) / 12;
    const sunX = canvas.width * 0.1 + canvas.width * 0.8 * tp;
    const sunY = canvas.height * 0.1 + Math.sin(tp * Math.PI) * -80;
    drawSprite(SUN, sunX, sunY, 8, season);
  } else {
    const nightH = h >= 18 ? h - 18 : h + 6;
    const tp = nightH / 12;
    drawSprite(
      MOON,
      canvas.width * 0.1 + canvas.width * 0.8 * tp,
      canvas.height * 0.15,
      8,
      season,
    );
  }

  // ── 5. Clouds ───────────────────────────────────────────────
  const cloudList =
    weather !== "rain" && weather !== "storm" && weather !== "snow"
      ? clouds
      : clouds.concat([
          { x: 35, y: 18, speed: 0.35, scale: 5 },
          { x: 70, y: 22, speed: 0.45, scale: 6 },
        ]);
  cloudList.forEach((c) => {
    c.x += c.speed;
    if (c.x > 110) c.x = -20;
    drawSprite(
      CLOUD,
      (c.x / 100) * canvas.width,
      (c.y / 100) * canvas.height,
      c.scale,
      season,
    );
  });

  // ── 6. Mountains ────────────────────────────────────────────
  const mtnSnow = season === "winter" || weather === "snow";
  drawBlockyMountain(
    canvas.width * 0.25,
    groundY,
    canvas.height * 0.45,
    canvas.width * 0.6,
    theme.mountain,
    theme.mountainLight,
    mtnSnow,
  );
  drawBlockyMountain(
    canvas.width * 0.75,
    groundY,
    canvas.height * 0.35,
    canvas.width * 0.5,
    theme.mountain,
    theme.mountainLight,
    mtnSnow,
  );
  drawBlockyMountain(
    canvas.width * 0.5,
    groundY,
    canvas.height * 0.25,
    canvas.width * 0.4,
    theme.mountain,
    theme.mountainLight,
    season === "winter",
  );

  // ── 7. Ground ───────────────────────────────────────────────
  ctx.fillStyle = SEASON_COLORS[season].grass2;
  ctx.fillRect(0, groundY, canvas.width, canvas.height - groundY);
  ctx.fillStyle = SEASON_COLORS[season].grass1;
  grassBlades.forEach((b) => {
    if (b.x < canvas.width)
      ctx.fillRect(b.x, groundY - b.height, b.width, b.height);
  });
  ctx.fillRect(0, groundY, canvas.width, canvas.height - groundY);

  // ── 8. Rocks, bushes, flowers ───────────────────────────────
  drawSprite(ROCK, canvas.width * 0.3, groundY - 15, 4, season);
  drawSprite(ROCK, canvas.width * 0.65, groundY - 10, 3, season);
  drawSprite(
    BUSH,
    canvas.width * 0.2,
    groundY - BUSH.length * 6 + 10,
    6,
    season,
  );
  drawSprite(
    BUSH,
    canvas.width * 0.85,
    groundY - BUSH.length * 5 + 5,
    5,
    season,
  );
  drawSprite(
    BUSH,
    canvas.width * 0.1,
    groundY - BUSH.length * 4 + 15,
    4,
    season,
  );
  if (season === "spring" || season === "summer") {
    grassBlades.forEach((b) => {
      if (b.isFlower && b.x < canvas.width)
        drawSprite(FLOWER, b.x, groundY + b.height * 2, 3, season);
    });
  }

  // ── 9. Side trees ───────────────────────────────────────────
  const seasonTrees = treeImgs[season];
  if (
    seasonTrees &&
    seasonTrees.small.complete &&
    seasonTrees.small.naturalWidth
  ) {
    const si = seasonTrees.small;
    const dsw = Math.min(canvas.width * 0.12, 260);
    const ss = dsw / si.naturalWidth;
    const sW = si.naturalWidth * ss;
    const sH = si.naturalHeight * ss;
    const bot = getBottomYFromRegion(
      si,
      0,
      0,
      si.naturalWidth,
      si.naturalHeight,
      _bottomCacheImg,
      si.src,
    );
    const nudge = sheetBottomNudgeValNum;
    ctx.drawImage(
      si,
      (tree1Pct / 100) * canvas.width - sW / 2,
      groundY - bot * ss + nudge + tree1YOff,
      sW,
      sH,
    );
    ctx.drawImage(
      si,
      (tree2Pct / 100) * canvas.width - sW / 2,
      groundY - bot * ss + nudge + tree2YOff,
      sW,
      sH,
    );
  } else if (treesSheetLoaded && treesSheet.naturalWidth) {
    const shW = treesSheet.naturalWidth,
      shH = treesSheet.naturalHeight;
    const tW = shW / 4,
      tH = shH / 2;
    const col = { winter: 0, spring: 1, summer: 2, autumn: 3 }[season] ?? 1;
    const dsw = Math.min(canvas.width * 0.12, 260);
    const ss = dsw / tW;
    const sW = tW * ss,
      sH = tH * ss;
    const botS = getBottomYFromRegion(
      treesSheet,
      col * tW,
      tH,
      tW,
      tH,
      _bottomCacheSheet,
      `${col}_1`,
    );
    ctx.drawImage(
      treesSheet,
      col * tW,
      tH,
      tW,
      tH,
      (tree1Pct / 100) * canvas.width - sW / 2,
      groundY - botS * ss + sheetBottomNudgeValNum + tree1YOff,
      sW,
      sH,
    );
    ctx.drawImage(
      treesSheet,
      col * tW,
      tH,
      tW,
      tH,
      (tree2Pct / 100) * canvas.width - sW / 2,
      groundY - botS * ss + sheetBottomNudgeValNum + tree2YOff,
      sW,
      sH,
    );
  } else {
    drawSprite(
      TREE,
      (tree1Pct / 100) * canvas.width,
      groundY - TREE.length * 8 + 15 + tree1YOff,
      8,
      season,
    );
    drawSprite(
      TREE,
      (tree2Pct / 100) * canvas.width,
      groundY - TREE.length * 8 + 15 + tree2YOff,
      8,
      season,
    );
  }

  // ── 10. Center tree ─────────────────────────────────────────
  let centerTreeImgX = centerTreeX;
  let centerTreeImgY = groundY - TREE.length * 8 + 25;
  let centerTreeImgW = 0,
    centerTreeImgH = 0;
  let centerHoleX = centerTreeX,
    centerHoleY = groundY,
    centerHoleR = 40;
  centerTreeUsingSheetTop = false;

  if (
    seasonTrees &&
    seasonTrees.center.complete &&
    seasonTrees.center.naturalWidth
  ) {
    const ci = seasonTrees.center;
    const dw = Math.min(canvas.width * 0.28, 520);
    const sc = dw / ci.naturalWidth;
    centerTreeImgW = ci.naturalWidth * sc;
    centerTreeImgH = ci.naturalHeight * sc;
    const imgBot = getBottomYFromRegion(
      ci,
      0,
      0,
      ci.naturalWidth,
      ci.naturalHeight,
      _bottomCacheImg,
      ci.src,
    );
    centerTreeImgX = canvas.width / 2 - centerTreeImgW / 2;
    centerTreeImgY =
      groundY - imgBot * sc + centerTreeYOffset + sheetBottomNudgeValNum;
    ctx.drawImage(
      ci,
      centerTreeImgX,
      centerTreeImgY,
      centerTreeImgW,
      centerTreeImgH,
    );
    centerHoleX = centerTreeImgX + centerTreeImgW * holeFrac.x;
    centerHoleY = centerTreeImgY + centerTreeImgH * holeFrac.y;
    centerHoleR = centerTreeImgW * holeFrac.r;
    centerHoleTarget = centerHoleX;
  } else if (treesSheetLoaded && treesSheet.naturalWidth) {
    const shW = treesSheet.naturalWidth,
      shH = treesSheet.naturalHeight;
    const tW = shW / 4,
      tH = shH / 2;
    const col = { winter: 0, spring: 1, summer: 2, autumn: 3 }[season] ?? 1;
    const row = shouldHide ? 0 : 1;
    const dw = Math.min(canvas.width * 0.28, 520);
    const sc = dw / tW;
    centerTreeImgW = tW * sc;
    centerTreeImgH = tH * sc;
    const sx = col * tW,
      sy = row * tH;
    const botTile = getBottomYFromRegion(
      treesSheet,
      sx,
      sy,
      tW,
      tH,
      _bottomCacheSheet,
      `${col}_${row}`,
    );
    centerTreeImgX = canvas.width / 2 - centerTreeImgW / 2;
    centerTreeImgY =
      groundY - botTile * sc + centerTreeYOffset + sheetBottomNudgeValNum;
    ctx.drawImage(
      treesSheet,
      sx,
      sy,
      tW,
      tH,
      centerTreeImgX,
      centerTreeImgY,
      centerTreeImgW,
      centerTreeImgH,
    );
    centerHoleX = centerTreeImgX + centerTreeImgW * holeFrac.x;
    centerHoleY = centerTreeImgY + centerTreeImgH * holeFrac.y;
    centerHoleR = centerTreeImgW * holeFrac.r;
    centerHoleTarget = centerHoleX;
    centerTreeUsingSheetTop = row === 0;
  } else {
    const fallbackY = groundY - TREE.length * 8 + 25 + centerTreeYOffset;
    drawSprite(TREE, centerTreeX, fallbackY, 9, season);
    centerHoleX = canvas.width / 2;
    centerHoleY = fallbackY + 220;
    centerHoleTarget = centerHoleX;
  }

  // ── 11. Hiding badge ────────────────────────────────────────
  if (
    raccoonState === "hiding" &&
    Math.abs(raccoonX - centerHoleTarget) < 160 &&
    centerTreeImgW > 0
  ) {
    const bx = centerTreeImgX + centerTreeImgW - 48;
    const by = centerTreeImgY + 24;
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.beginPath();
    ctx.arc(bx, by, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.95)";
    ctx.font = '16px "Outfit", sans-serif';
    ctx.textAlign = "center";
    ctx.fillText("😴", bx, by + 6);
  }

  // ── 12. Bonfire + fireflies (night) ─────────────────────────
  if (isNight) {
    const bfX = (bonfirePct / 100) * canvas.width;

    if (bonfireImgLoaded && bonfireImg.naturalWidth) {
      const bfSc = 80 / bonfireImg.naturalHeight;
      const bfW = bonfireImg.naturalWidth * bfSc;
      const bfH = bonfireImg.naturalHeight * bfSc;
      // glow
      ctx.save();
      ctx.globalAlpha = (Math.sin(Date.now() / 200) + 1) / 8 + 0.1;
      ctx.fillStyle = "#e67e22";
      ctx.beginPath();
      ctx.arc(bfX, groundY - 20, 80, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      ctx.drawImage(
        bonfireImg,
        bfX - bfW / 2,
        groundY - bfH + bonfireYOff,
        bfW,
        bfH,
      );
    } else {
      const bfSprite =
        Math.floor(Date.now() / 150) % 2 === 0 ? BONFIRE_1 : BONFIRE_2;
      drawSprite(
        bfSprite,
        bfX,
        groundY - BONFIRE_1.length * 6 + 15 + bonfireYOff,
        6,
        season,
      );
      ctx.fillStyle = `rgba(230,126,34,${(Math.sin(Date.now() / 200) + 1) / 8 + 0.1})`;
      ctx.beginPath();
      ctx.arc(bfX + 33, groundY - 10, 90, 0, Math.PI * 2);
      ctx.fill();
    }

    if (weather === "clear" && (season === "summer" || season === "spring")) {
      fireflies.forEach((fly) => {
        fly.x += fly.speedX;
        fly.y += fly.speedY;
        if (fly.x < 0 || fly.x > canvas.width) fly.speedX *= -1;
        if (fly.y < groundY - 50 || fly.y > canvas.height) fly.speedY *= -1;
        fly.phase += 0.05;
        const glow = (Math.sin(fly.phase) + 1) / 2;
        ctx.fillStyle = `rgba(241,196,15,${glow})`;
        ctx.beginPath();
        ctx.arc(fly.x, fly.y, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = `rgba(241,196,15,${glow * 0.3})`;
        ctx.beginPath();
        ctx.arc(fly.x, fly.y, 8, 0, Math.PI * 2);
        ctx.fill();
      });
    }
  }

  // ── 13. Raccoon ─────────────────────────────────────────────
  raccoon.frame++;
  if (raccoonState === "walking") {
    if (raccoon.frame % 15 === 0)
      raccoon.bounceOffset = raccoon.bounceOffset === 0 ? -25 : 0;
  } else {
    if (raccoon.frame % 45 === 0) {
      if (Math.random() > 0.6) raccoon.flip = !raccoon.flip;
      raccoon.bounceOffset = raccoon.bounceOffset === 0 ? -10 : 0;
    }
  }

  if (
    raccoonImg.complete &&
    raccoonImg.naturalHeight !== 0 &&
    raccoonScale > 0
  ) {
    const spW = 260,
      spH = 260;
    const hidingAtCenter =
      raccoonState === "hiding" && Math.abs(raccoonX - centerHoleTarget) < 160;

    // shadow
    if (raccoonScale > 0.3) {
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.beginPath();
      ctx.ellipse(
        raccoonX,
        groundY,
        (raccoon.bounceOffset === 0 ? 60 : 40) * raccoonScale,
        8 * raccoonScale,
        0,
        0,
        Math.PI * 2,
      );
      ctx.fill();
    }

    if (hidingAtCenter) {
      raccoonX = centerHoleTarget;
      if (!centerTreeUsingSheetTop) {
        const iW = spW * 0.6 * raccoonScale,
          iH = spH * 0.6 * raccoonScale;
        ctx.save();
        ctx.translate(centerHoleX, centerHoleY + iH * 0.08);
        ctx.rotate(-0.08);
        ctx.drawImage(raccoonImg, -iW / 2, -iH / 2, iW, iH);
        // closed eyes
        ctx.strokeStyle = "rgba(20,20,20,0.95)";
        ctx.lineWidth = Math.max(2, iW * 0.02);
        ctx.lineCap = "round";
        const eyeY = -iH * 0.12,
          eyeLX = -iW * 0.12,
          eyeRX = iW * 0.12;
        ctx.beginPath();
        ctx.moveTo(eyeLX - iW * 0.04, eyeY);
        ctx.quadraticCurveTo(eyeLX, eyeY + iH * 0.03, eyeLX + iW * 0.04, eyeY);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(eyeRX - iW * 0.04, eyeY);
        ctx.quadraticCurveTo(eyeRX, eyeY + iH * 0.03, eyeRX + iW * 0.04, eyeY);
        ctx.stroke();
        // Zs
        ctx.fillStyle = "rgba(255,255,255,0.9)";
        ctx.font = `${Math.max(12, Math.floor(iW * 0.08))}px "Outfit", sans-serif`;
        ctx.textAlign = "center";
        for (let i = 0; i < 3; i++) {
          ctx.globalAlpha = 1 - i * 0.28;
          ctx.fillText(
            "Z",
            iW * 0.18 + i * iW * 0.06,
            -iH * 0.6 - i * iH * 0.12,
          );
        }
        ctx.globalAlpha = 1;
        ctx.restore();
      }
    } else {
      ctx.save();
      ctx.translate(raccoonX, groundY + raccoon.bounceOffset);
      ctx.scale(raccoonScale, raccoonScale);
      if (raccoonState === "walking") {
        if (raccoon.bounceOffset !== 0) ctx.scale(0.95, 1.05);
        else ctx.scale(1.05, 0.95);
      } else {
        if (raccoon.bounceOffset !== 0) ctx.scale(1.02, 0.98);
      }
      if (raccoon.flip) ctx.scale(-1, 1);
      ctx.drawImage(raccoonImg, -spW / 2, -spH + 110, spW, spH);
      ctx.restore();
    }
  }

  // ── 14. Rain / Snow ─────────────────────────────────────────
  if (weather === "rain" || weather === "storm")
    drawRain(groundY, weather === "storm" ? 1 : 0.6);
  else if (weather === "snow") drawSnow();

  // ── 15. Lightning ───────────────────────────────────────────
  if (lightningFlash > 0) {
    ctx.fillStyle = `rgba(255,255,255,${lightningFlash / 20})`;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    lightningFlash -= 1;
  }

  // ── 16. Weather text overlay ────────────────────────────────
  drawWeatherText(weather, themeName, season);

  requestAnimationFrame(loop);
}

// ─── INIT ────────────────────────────────────────────────────
window.addEventListener("resize", resize);
window.addEventListener("load", () => {
  resize();
  loadTreeImages();
  fetchWeatherForCity(currentCity);
  loop();
});
